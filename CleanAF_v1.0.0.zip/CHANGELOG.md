# Changelog

## 1.0.0
- Initial public release of CleanAF
- One-click desktop cleanup
- Auto-sorts by file type
- Preserves system icons and the app itself
- Duplicate-safe moves, timestamped runs